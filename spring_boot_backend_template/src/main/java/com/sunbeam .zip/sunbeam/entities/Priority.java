package com.sunbeam.entities;

public enum Priority {
	LOW,MEDIUM,HIGH
}
