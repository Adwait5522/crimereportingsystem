package com.sunbeam.entities;

public enum Status {
	PENDING,INVESTIGATING,RESOLVED,REJECTED
}
