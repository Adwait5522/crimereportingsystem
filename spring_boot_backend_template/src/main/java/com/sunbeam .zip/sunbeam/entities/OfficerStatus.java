package com.sunbeam.entities;

public enum OfficerStatus {
	ACTIVE,
    INACTIVE,
    SUSPENDED
	
}
